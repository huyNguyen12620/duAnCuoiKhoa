//tsrfc
import React from 'react'

type Props = {}

export default function Detail({}: Props) {
  return (
    <div>Detail</div>
  )
}