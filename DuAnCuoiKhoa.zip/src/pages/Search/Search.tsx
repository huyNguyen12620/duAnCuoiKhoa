import React from 'react'

type Props = {}

export default function Search({}: Props) {
  return (
    <div>Search</div>
  )
}