import React from 'react'


type Props = {}

export default function TuvanKhoahoc({ }: Props) {
  const tuvan = require("../../assets/img/tuvan.jpg")
  return (
    <div className='tuvankhoahoc'>
      <div className="container-xxl py-6">
        <div className="container">
          <div className="row g-5">
            <div className="col-lg-6">
              <h6 className="text-primary text-uppercase mb-2">Bạn cần hỗ trợ?</h6>
              <h1 className="display-6 mb-4">TỪ ZERO TRỞ THÀNH "CODER"</h1>
              <p className="mb-5">Hàng nghìn học viên trên cả nước đã tốt nghiệp và hiện đang làm việc tại các công ty phần mềm.
                Bạn vừa mới tốt nghiệp cấp 3, hoặc đang là công nhân, hay đang đi học hoặc đi làm các ngành nghề khác không liên quan đến công nghệ, hay là đang thất nghiệp… đều có thể bắt đầu.
              </p>
              <div className="row gy-5 gx-4">
                <div className="col-sm-6">
                  <div className="d-flex align-items-center mb-3">
                    <div className="flex-shrink-0 btn-square bg-primary me-3">
                      <i className="fa fa-check text-white"></i>
                    </div>
                    <h5 className="mb-0">Tư vấn khóa học</h5>
                  </div>
                  <span>Magna sea eos sit dolor, ipsum amet ipsum lorem diam eos</span>
                </div>
                <div className="col-sm-6">
                  <div className="d-flex align-items-center mb-3">
                    <div className="flex-shrink-0 btn-square bg-primary me-3">
                      <i className="fa fa-check text-white"></i>
                    </div>
                    <h5 className="mb-0">Lựa chọn khóa học</h5>
                  </div>
                  <span>Magna sea eos sit dolor, ipsum amet ipsum lorem diam eos</span>
                </div>
                <div className="col-sm-6">
                  <div className="d-flex align-items-center mb-3">
                    <div className="flex-shrink-0 btn-square bg-primary me-3">
                      <i className="fa fa-check text-white"></i>
                    </div>
                    <h5 className="mb-0">Bạn là dân trái ngành?</h5>
                  </div>
                  <span>Magna sea eos sit dolor, ipsum amet ipsum lorem diam eos</span>
                </div>
                <div className="col-sm-6" >
                  <div className="d-flex align-items-center mb-3">
                    <div className="flex-shrink-0 btn-square bg-primary me-3">
                      <i className="fa fa-check text-white"></i>
                    </div>
                    <h5 className="mb-0">Bạn là sinh viên nghành CNTT?</h5>
                  </div>
                  <span>Magna sea eos sit dolor, ipsum amet ipsum lorem diam eos</span>
                </div>
              </div>
            </div>
            <div className="col-lg-6">
              <div className="position-relative overflow-hidden pe-5 pt-5 h-100" style={{ minHeight: '500px' }}>
                <img className="position-absolute w-100 h-100" src={tuvan} alt="hinh tu van" style={{ objectFit: 'cover' }} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}