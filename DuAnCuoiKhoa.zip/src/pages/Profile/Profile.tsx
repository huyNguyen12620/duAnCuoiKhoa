import React from 'react'

type Props = {}

export default function Profile({}: Props) {
  return (
    <div>Profile</div>
  )
}